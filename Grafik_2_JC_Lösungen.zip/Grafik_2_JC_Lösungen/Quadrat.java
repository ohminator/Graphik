import sum.kern.*;

public class Quadrat extends Figur {

    public Quadrat(double pHPosition, double pVPosition, double pGroesse) {
        super(pHPosition, pVPosition, pGroesse);
    }

    
    public void zeichne() {
        hatStift.zeichneRechteck(zGroesse, zGroesse);
    }

    
    public boolean getroffen(double pHPosition, double pVPosition) {
        return pHPosition >= this.hPosition() &&
               pHPosition <= this.hPosition() + zGroesse &&
               pVPosition >= this.vPosition() &&
               pVPosition <= this.vPosition() + zGroesse;
    }
}
