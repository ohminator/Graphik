import sum.kern.*;

public class Kreis
{
    // Objektnamen
    Buntstift hatStift;
    
    // Attribute
    double zGroesse;
    
    //Konstruktor
    public Kreis(double pHPosition, double pVPosition, double pGroesse)
    {
        hatStift = new Buntstift();
        zGroesse = pGroesse;
        hatStift.bewegeBis(pHPosition, pVPosition);
        this.zeichne();
    }
    
    // andere Dienste
    public void zeichne()
    {
        hatStift.zeichneKreis(zGroesse);
    }
    
    public void loesche()
    {
        hatStift.radiere();
        this.zeichne();
        hatStift.normal();
    }
    
    public void setzeFarbe(int pFarbe)
    {
        this.loesche();
        hatStift.setzeFarbe(pFarbe);
        this.zeichne();
    }
    
    public void bewegeBis(double pHPosition, double pVPosition)
    {
        this.loesche();
        hatStift.bewegeBis(pHPosition, pVPosition);
        this.zeichne(); 
    }
    
    public void bewegeUm(double pHDistanz, double pVDistanz)
    {
        this.bewegeBis(this.hPosition()+pHDistanz, this.vPosition()+pVDistanz);
    }
    
    public double hPosition()
    {
        return hatStift.hPosition();
    }
    
    public double vPosition()
    {
        return hatStift.vPosition();
    }
    
    public void setzeGroesse(double pGroesse)
    {
        this.loesche();
        zGroesse = pGroesse;
        this.zeichne(); 
    }
    
    public double groesse()
    {
        return zGroesse;
    }
    
    public boolean getroffen(double pHPosition, double pVPosition)
    {
        return (pHPosition - this.hPosition()) * (pHPosition - this.hPosition())
            + (pVPosition - this.vPosition()) * (pVPosition - this.vPosition())
            <= zGroesse * zGroesse;
    }
    
    public void aktiviere()
    {
        this.loesche();
        hatStift.setzeLinienBreite(3);
        this.zeichne(); 
    }
    
    public void deaktiviere()
    {
        this.loesche();
        hatStift.setzeLinienBreite(1);
        this.zeichne(); 
    }
    
    public void gibFrei()
    {
              hatStift.gibFrei();
    }
}

