import sum.kern.*;

public class Grafik1
{
    //Bezugsobjekte
    
    Bildschirm derBildschirm;
    Tastatur dieTastatur;
    Maus dieMaus;
    Kreis meinKreis1,meinKreis2, meinKreis3;
    Kreis aktiverKreis;
    public Grafik1()
    {
        // Initialisierung
        derBildschirm = new Bildschirm(700,700);
        dieTastatur = new Tastatur();
        dieMaus = new Maus();
        meinKreis1 = new Kreis(100, 100, 50);
        meinKreis2 = new Kreis(300, 200, 100);
        meinKreis3 = new Kreis(500, 100, 100);
      }
      
      public void fuehreAus() {
        // Aktionsteil
        aktiverKreis = meinKreis1;
        aktiverKreis.aktiviere();
       

        do
        {
            if (dieMaus.istGedrueckt())
            {
                if (!aktiverKreis.getroffen(dieMaus.hPosition(), dieMaus.vPosition()))
                {
                    aktiverKreis.deaktiviere();
                    if (meinKreis1.getroffen(dieMaus.hPosition(), dieMaus.vPosition()))
                            aktiverKreis = meinKreis1;
                    if (meinKreis2.getroffen(dieMaus.hPosition(), dieMaus.vPosition()))
                            aktiverKreis = meinKreis2;
                    if (meinKreis3.getroffen(dieMaus.hPosition(), dieMaus.vPosition()))
                            aktiverKreis = meinKreis3;
                    aktiverKreis.aktiviere();
                } // if
                
            } // if
            
            if (dieTastatur.wurdeGedrueckt())
            {
                switch (dieTastatur.zeichen())
                {
                    case Zeichen.PFEILOBEN:
                            aktiverKreis.bewegeUm(0,-10);
                            break;
                    case Zeichen.PFEILUNTEN:
                            aktiverKreis.bewegeUm(0,10);
                            break;
                    case Zeichen.PFEILLINKS:
                            aktiverKreis.bewegeUm(-10,0);
                            break;
                    case Zeichen.PFEILRECHTS:
                            aktiverKreis.bewegeUm(10,0);
                            break;
                    case '1':
                            aktiverKreis.setzeGroesse(20);
                            break;
                    case '2':
                            aktiverKreis.setzeGroesse(40);
                            break;
                    case '3':
                            aktiverKreis.setzeGroesse(60);
                            break;
                    case '4':
                            aktiverKreis.setzeGroesse(80);
                            break;
                    case '5':
                            aktiverKreis.setzeGroesse(100);
                            break;
                    case '6':
                            aktiverKreis.setzeGroesse(120);
                            break;
                    case '7':
                            aktiverKreis.setzeGroesse(140);
                            break;
                    case '8':
                            aktiverKreis.setzeGroesse(160);
                            break;
                    case '9':
                            aktiverKreis.setzeGroesse(180);
                            break;
                    case 'r':
                            aktiverKreis.setzeFarbe(Farbe.ROT);
                            break;
                    case 'g':
                            aktiverKreis.setzeFarbe(Farbe.GRUEN);
                            break;
                    case 'b':
                            aktiverKreis.setzeFarbe(Farbe.BLAU);
                            break;
                    case 's':
                            aktiverKreis.setzeFarbe(Farbe.SCHWARZ);
                            break;
                    case 'o':
                            aktiverKreis.setzeFarbe(Farbe.ORANGE);
                            break;
                    case 'c':
                            aktiverKreis.setzeFarbe(Farbe.CYAN);
                            break;
                    case 'm':
                            aktiverKreis.setzeFarbe(Farbe.MAGENTA);
                            break;
                } // switch
                dieTastatur.weiter();
            } // if
        }
        while (!dieMaus.doppelKlick());
        
        // Aufraeumen
        meinKreis1.gibFrei();
        meinKreis2.gibFrei();
        meinKreis3.gibFrei();
        dieMaus.gibFrei();
        dieTastatur.gibFrei();
        derBildschirm.gibFrei();
    }
}

