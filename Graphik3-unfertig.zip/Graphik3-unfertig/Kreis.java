import sum.kern.*;

public class Kreis extends figur
{
    // Objektnamen
    Buntstift hatStift;
    
    //Konstruktor
    public Kreis(double pHPosition, double pVPosition, double pGroesse)
    {
        super(pHPosition, pVPosition, pGroesse);
        zGroesse = pGroesse;
    }
    
    // andere Dienste
    public void zeichne()
    {
        hatStift.zeichneKreis(zGroesse);
        //super.zeichne();
    }

    public boolean getroffen(double pHPosition, double pVPosition)
    {
        return (pHPosition - this.hPosition()) * (pHPosition - this.hPosition())
            + (pVPosition - this.vPosition()) * (pVPosition - this.vPosition())
            <= zGroesse * zGroesse;
    }
}

